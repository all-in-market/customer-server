# ==================================================
# 공용 변수
# ==================================================
aws_region   = "ap-northeast-2"
project_name = "all-in-market"

vpc_cidr = "10.0.0.0/16"

public_subnet_cidrs      = ["10.0.0.0/20", "10.0.16.0/20"]
ecs_private_subnet_cidrs = ["10.0.128.0/20", "10.0.144.0/20"]
data_private_subnet_cidrs = ["10.0.160.0/20", "10.0.176.0/20"]
availability_zones       = ["ap-northeast-2a", "ap-northeast-2b"]

enable_s3_vpc_endpoint = true

db_name            = "allinmarket"
db_username        = "postgres"
db_password        = "CHANGE_ME_RDS_PASSWORD_LATER"
db_instance_class  = "db.t3.micro"
db_allocated_storage = 20

log_retention_in_days = 30

redis_node_type = "cache.t3.micro"

github_owner  = "all-in-market"

# HTTPS 필수: Route53 public hosted zone이 먼저 존재해야 함
# 예: domain_name = "api.example.com" / route53_zone_name = "example.com"
domain_name       = "hyu1335.cloud"
route53_zone_name = "hyu1335.cloud"

# dev / prod 값만 가능
# prod 인 경우 terraform destroy로 RDS 삭제가 막힘
environment = "dev"


# ==================================================
# Customer - Fargate (ECS Task)
# ==================================================
customer_container_name  = "all-in-market-customer"
customer_container_port  = 8080

customer_ecr_repository_name = "all-in-market-customer"
customer_image_tag           = "latest"

# 1 vCPU + 2GB 메모리
customer_ecs_task_cpu    = 1024
customer_ecs_task_memory = 2048
customer_ecs_desired_count = 0

customer_health_check_path     = "/actuator/health"

customer_github_repo   = "mvp-api-server"
customer_github_branches = ["dev", "main"]

customer_environment_variables = {
  JWT_SECRET      = "gwrhge53hserwgawfasfasd53hesatwtraygf4yhest"
  PGADMIN_EMAIL   = "pgadmin4@gmail.com"
  PGADMIN_PASSWORD = "pgadmin4"
  SELLER_ID       = "super@ticket-topia.com"
  SELLER_PASSWORD = "superadmin1234!"
}


# ==================================================
# Admin - EC2 (ECS Container Instance)
# ==================================================
admin_enabled             = true

admin_container_name      = "all-in-market-admin"
admin_container_port      = 8081

admin_ecr_repository_name = "all-in-market-admin"
admin_image_tag           = "latest"

# 0.5 vCPU + 1GB 메모리
admin_ecs_task_cpu      = 512
admin_ecs_task_memory   = 1024
admin_ecs_desired_count = 0

admin_health_check_path   = "/actuator/health"

admin_github_repo   = "mvp-admin-server"
admin_github_branches = ["dev", "main"]

admin_path_patterns       = ["/admin", "/admin/*"]
admin_listener_rule_priority = 10

admin_instance_type       = "t3.small"
admin_root_volume_size    = 40

# 관리자 서버에서 별도로 필요한 환경변수 값이 있으면 여기에 추가
admin_environment_variables = {
  ADMIN_ID       = "admin@test.com"
  ADMIN_PASSWORD = "12345678"
  JWT_SECRET     = "xYQ5Dl5HieGyfY0BH7h8RJxMLjHBwRPG5xfKYaGw2oP"
  PGADMIN_EMAIL   = "pgadmin4@gmail.com"
  PGADMIN_PASSWORD = "pgadmin4"
}

# ==================================================
# Alarm - Fargate
# ==================================================
alarm_container_name = "all-in-market-alarm"
alarm_container_port = 8082

alarm_ecr_repository_name = "all-in-market-alarm"
alarm_image_tag           = "latest"

alarm_ecs_task_cpu      = 512
alarm_ecs_task_memory   = 1024
alarm_ecs_desired_count = 0

alarm_health_check_path = "/actuator/health"

alarm_github_repo     = "alarm-server"
alarm_github_branches = ["dev", "main"]

alarm_path_patterns = ["/ws", "/ws/*", "/internal/notifications/*", "/alarm", "/alarm/*"]
alarm_listener_rule_priority = 20

alarm_environment_variables = {
  JWT_SECRET = "tzejsxqrt24fwegawergmbvrio43ogjmwszbj"
  PGADMIN_EMAIL   = "pgadmin4@gmail.com"
  PGADMIN_PASSWORD = "pgadmin4"
  SELLER_ID       = "super@ticket-topia.com"
  SELLER_PASSWORD = "superadmin1234!"
}
